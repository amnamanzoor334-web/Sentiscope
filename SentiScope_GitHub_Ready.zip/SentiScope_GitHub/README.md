# SentiScope

A working customer feedback sentiment analysis demo with a dark dashboard, lime accents, review filters, and an interactive analyzer.

![SentiScope dashboard](screenshots/Dashboard.jpg)

## Run it immediately

1. Extract the ZIP.
2. Open the `SentiScope_GitHub` folder.
3. Double-click **index.html** in a modern browser.
4. Open **Review analyzer**, type an English review, and select **Analyze sentiment**.
5. Select **Add to feedback collection** to update the dashboard.

No API key, paid account, database, npm installation, or Python installation is required to use the included app. The pretrained model is already bundled. Keep all app files in the same folder. JavaScript must be enabled.

If your browser restricts local scripts, serve the folder with Python:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`. On Windows, `py -m http.server 8000` also works.

## What works

- Positive, negative, and neutral classification for individual English reviews.
- A breakdown of the model scores across all three classes.
- Twelve synthetic sample reviews with predicted categories.
- Session totals, category counts, and a distribution chart.
- Category filters and resetting the sample collection.
- Adding your analyzed review to the current collection.
- Input validation and safe rendering of entered text.
- Responsive layouts for desktop and mobile screens.

The app starts with sample data. Reviews stay in browser memory and reset on refresh; they are not sent to a server. CSV upload and a database are not included.

## How the model works

Python trains a scikit-learn TF-IDF vectorizer using word unigrams and bigrams and a logistic regression classifier. Vocabulary, IDF weights, coefficients, and intercepts are exported to `model.js`. `sentiment.js` runs the same feature transformation, normalization, and classifier in the browser. This is a trained model; the frontend does not assign sentiment using a fixed keyword list.

Training uses **180 synthetic sentences derived from 60 author-written base examples**. The training data is included in `training_data.json`. No real customer data is included. This small demonstration model has **not been evaluated on an independent benchmark**. Model scores are not measured accuracy or calibrated confidence. Sarcasm, mixed sentiment, unfamiliar terms, and Roman Urdu may be misclassified. Human review is needed before using predictions for business decisions.

## Retrain the model

Python 3.11 or newer is required only for training and the model parity check.

```bash
python -m venv .venv
```

Activate the environment:

```bash
# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS or Linux
source .venv/bin/activate
```

Then:

```bash
python -m pip install -r requirements.txt
python train_model.py
```

Reload the app after training. The script contains the base example corpus and writes `training_data.json` and `model.js` next to itself. To change the training examples, edit the `base` dictionary in `train_model.py`. Editing `training_data.json` alone does not change the training script's corpus.

## Verification

With Node.js and Python dependencies installed:

```bash
node tests/test_model.cjs
python tests/check_parity.py
```

These checks cover input validation, sentiment examples, output probabilities, browser-versus-Python inference parity, and required app files. They are implementation checks, not proof of model accuracy on real-world data.

## Upload to GitHub

1. Create a repository named `sentiscope` on GitHub.
2. Extract this ZIP on your computer.
3. Upload the **contents inside** `SentiScope_GitHub` to the repository root. Do not upload only the ZIP, and do not put an extra `SentiScope_GitHub` folder around the app in the repository.
4. Confirm that `index.html`, `app.js`, `sentiment.js`, `model.js`, and `style.css` appear at the repository root.
5. Commit the files. Screenshots are in `screenshots/` and display in this README.

Suggested description: **An educational AI customer feedback sentiment analysis prototype with browser inference and an interactive dashboard.**

## Enable a live GitHub Pages website

In the repository, go to **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**. Choose **main** and **/(root)**, then save. GitHub will show the website address after deployment. Use the address GitHub provides.

All asset references are relative, so this app supports both repository Pages paths and a normal website root. The included `.nojekyll` file disables Jekyll processing; if the file is missing after upload, create an empty `.nojekyll` file at the repository root.

Official instructions:
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Files

| File | Purpose |
| --- | --- |
| `index.html` | App interface and asset loading |
| `style.css` | Dashboard styling and responsive layouts |
| `app.js` | User interactions and session state |
| `sentiment.js` | Browser and Node inference engine |
| `model.js` | Bundled pretrained model parameters |
| `train_model.py` | Reproducible Python model training |
| `training_data.json` | Synthetic labelled training sentences |
| `requirements.txt` | Python training dependency |
| `tests/` | Model validation and Python parity checks |
| `screenshots/` | Four genuine demo screenshots |

## Internship use

This repository contains an educational demonstration. Describe the work and assistance you actually used, learn the workflow, and confirm the project with your internship supervisor before reporting it as internship work. The screenshots illustrate the interface and example predictions, not completed company activities or benchmark results.
