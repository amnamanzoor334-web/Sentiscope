/* Browser and Node compatible inference engine. */
(function(root) {
function classify(text, M){if(typeof text!=='string'||!text.trim())throw Error('Enter a customer review first.');if(text.length>2000)throw Error('Keep your review within 2,000 characters.');const tokens=text.toLowerCase().match(/\b\w\w+\b/g)||[];const grams=[...tokens,...tokens.slice(0,-1).map((t,i)=>t+' '+tokens[i+1])],counts={};grams.forEach(t=>{const i=M.vocabulary[t];if(i!==undefined)counts[i]=(counts[i]||0)+1});const entries=Object.entries(counts).map(([i,n])=>[+i,n*M.idf[+i]]),norm=Math.sqrt(entries.reduce((n,[i,v])=>n+v*v,0))||1;const z=M.coef.map((row,k)=>M.intercept[k]+entries.reduce((s,[i,v])=>s+row[i]*v/norm,0));const exp=z.map(v=>Math.exp(v-Math.max(...z))),sum=exp.reduce((a,b)=>a+b,0),scores=exp.map(v=>v/sum),index=scores.indexOf(Math.max(...scores));return {label:M.classes[index],score:scores[index],scores:Object.fromEntries(M.classes.map((c,i)=>[c,scores[i]])),recognized:entries.length};}

const api = { classify };
if (typeof module === "object" && module.exports) module.exports = api;
else root.SentiModel = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
