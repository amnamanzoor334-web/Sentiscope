"""Check exported JavaScript inference against the Python training pipeline."""
import json,subprocess
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'training_data.json').read_text())
v=TfidfVectorizer(ngram_range=(1,2),lowercase=True,token_pattern=r'(?u)\b\w\w+\b')
c=LogisticRegression(C=5,max_iter=1000).fit(v.fit_transform([r['text'] for r in data]),[r['label'] for r in data])
inputs=['Excellent service and friendly staff. I love this product.', 'The delivery was late and the item was damaged. Terrible service.', 'The package arrived on Monday. The box contains a cable and a manual.', 'Fast delivery but poor quality.', 'It works perfectly!', 'The delivery is scheduled for tomorrow.', 'Very bad, disappointing and broken.', 'zzzzqqqqxxxx', 'GOOD value for money.']
r=subprocess.run(['node',str(root/'tests/test_model.cjs'),'--predict-json'],input=json.dumps(inputs),text=True,capture_output=True,check=True)
actual=json.loads(r.stdout);expected=c.predict_proba(v.transform(inputs))
for i,x in enumerate(actual):
 values=np.array([x['scores'][k] for k in c.classes_]);assert np.allclose(values,expected[i],rtol=1e-10,atol=1e-10),(i,values,expected[i])
 assert x['label']==c.classes_[expected[i].argmax()]
print(f'PASS: JavaScript and Python agree on labels and probabilities for {len(inputs)} inputs. This is an inference parity check, not a benchmark accuracy measurement.')
